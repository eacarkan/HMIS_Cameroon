# Gate 4 — UI / Workflow implementation bundle

Branch: `feature/gate4-ui-workflows` (from Gate 3 commit `716762c`). Uncommitted — for
mentor review. Paths are relative to `03_Software/HMIS_Cameroon/`.
Companion report (sent separately): `03_Software/Planning/26_Gate_4_UI_Workflow_Implementation_Report.md`.

All suites green: typecheck · lint · build · unit/component 39 · integration 41 · E2E 8 ·
smoke (GOLDEN PATH PASSED) · check:arch · check:privacy. Fake data only. No schema change.

## UI pages (changed/new)
- app/(app)/administration/page.tsx — configuration page (departments / service units / settings / templates)
- app/(app)/administration/tarifs/page.tsx — tariff & price-list management (NEW)
- app/(app)/patients/[id]/page.tsx — + patient identity/contact/duplicate panel
- app/(app)/encounters/[id]/page.tsx — + structured observations/diagnoses

## Components (NEW)
- components/admin/config-forms.tsx — config create/deactivate forms
- components/admin/tariff-forms.tsx — tariff/price-list forms
- components/patients/patient-identity-panel.tsx — contacts/identifiers/duplicate (no merge)
- components/consultations/clinical-structure-panel.tsx — vitals/diagnosis
- components/layout/nav.ts — Administration nav gated by config.read (director read-only)

## Server actions (thin transport → existing Gate 3 services) (NEW + billing)
- server/actions/config-actions.ts, tariff-actions.ts, patient-identity-actions.ts, clinical-structure-actions.ts
- server/actions/billing-actions.ts — cashier tariff-source (snapshot preserved)

## Server (minimal, additive — see report §16)
- server/services/patient-identity-service.ts — + listDuplicateCandidatesForActor (read wrapper, RBAC-checked)
- server/services/index.ts — export it

## i18n / labels / seed (test-isolation)
- messages/fr.json — French strings for the new UI
- lib/constants/index.ts — French labels for the new audit event codes
- prisma/seed-data.ts — clearOperationalData resets config/tariff tables (fake data; NO schema change)

## Tests
- tests/component/gate4-panels.test.tsx (NEW) — panels render + RBAC hiding + no-merge
- tests/component/sidebar.test.tsx — director sees Administration (read-only)

## Screenshots (production mode, validated, fake data) + tooling
- docs/gate4-screenshots/01..07 + README.md
- scripts/capture-review-screenshots.{sh,mjs}, scripts/seed-review-fixture.ts, package.json — `npm run screenshots:gate4`

> Server-side RBAC (Gate 3) remains the real control; the UI only hides actions a role can't perform.
> Not authorized by this batch: production deployment, real patient data, Phase 2/4 modules, schema changes.
