# Claude Code Prompt — Phase 1A · Batch 1B — Encounter lifecycle strengthening

> **Status: ✅ Ready to run** (after Batch 1A is merged & approved). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 1B).

## Role & context
Continue Phase 1A pilot-core strengthening on **fake/demo data**. This batch gives encounters **defined states, traceable history, and service/department context**, plus a **read-only patient timeline**.

## Hard boundaries (do not violate)
- **Fake/demo data only**; no real data; no production DB; no secrets/URLs.
- **No production/operational/real-data authorization** (not Gate 7).
- **No Phase 2 modules** (no inpatient/emergency encounter types, no queue).
- **Do not modify** `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- **Architecture layering** and **ESLint/`check-architecture`** rules as in Batch 1A.
- **Server-side RBAC, append-only audit, hospital scoping** on every new path.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Create branch `feature/phase1a-batch-1b-encounter-lifecycle` from a clean base (Batch 1A merged).
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 1B.

## Scope (tasks)
1. **Patient timeline** (encounters, invoices, key events) — **read-only aggregation first**.
2. **Encounter status rules** — defined transitions; invalid transitions rejected.
3. **Encounter service / department assignment.**
4. **Encounter status history.**

## Implementation rules specific to this batch
- **Timeline rule:** build the timeline as a **read-only service composed from** `Patient`, `Encounter`, `Consultation`, `Invoice`, `Payment`, receipt data, and `AuditLog` where appropriate. **Do not create a new timeline persistence model** unless required and approved.
- **Encounter status-history rule — SCHEMA DECISION REQUIRED BEFORE CODING:** first inspect the current schema and answer: *can encounter status history be represented using existing audit logs, or does it need a new `EncounterStatusHistory` table?* If a **new table is needed, STOP and propose it first** (additive, reviewed migration). Do not introduce it unilaterally.
- Status transitions live in the **encounter service**; invalid transitions must be rejected and tested.

## Files likely affected (confirm before editing)
encounter service/db, `server/services/clinical-structure-service`, `server/db/clinical-structure.ts`, `app/(app)/patients/[id]/*`, `app/(app)/encounters/[id]/*`, `features/patients/*`, `features/encounters/*`.

## Tests required
- **Unit:** status-transition validation; timeline composition.
- **Component:** timeline view; encounter status controls.
- **Integration:** status change → audit/history.
- **E2E:** encounter lifecycle (open → progress → close) with invalid-transition rejection.

## Acceptance criteria
- A patient profile shows a **chronological, read-only timeline**.
- An encounter **cannot move to an invalid status**.
- **Every status change is audited.**
- Service/department assignment is recorded.
- **Hospital scoping is enforced** for all new queries.

## Evidence required in your final response (doc 30 §12)
branch · commit status · files changed · **schema changes (state the status-history decision and its outcome)** · migrations (if any, additive + reviewed) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (timeline, valid/invalid transition, status history, dept assignment) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 1B: strengthen encounter lifecycle`

## Explicit exclusions
No inpatient/emergency encounters; no appointment/queue module; no Phase 2 content; **no new timeline persistence model without approval**.

## Stop conditions
Stop and propose if encounter status history requires a new table; stop if any change would touch contract/admin folders or introduce a Phase 2 concept.
