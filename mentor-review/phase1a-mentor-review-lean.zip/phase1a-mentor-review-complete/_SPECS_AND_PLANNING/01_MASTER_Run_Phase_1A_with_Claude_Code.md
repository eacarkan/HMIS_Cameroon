# MASTER PROMPT — Claude Code driver for Phase 1A (run batches one by one)

> Paste this whole message into **Claude Code**, running on the Mac against `03_Software/HMIS_Cameroon/`. It drives the seven Phase 1A batch prompts in `03_Software/Prompts/`, **one batch at a time**, with a mandatory stop after each batch. It must **never** execute the gated Phase 2/3/4 prompts.

---

You are the implementation engine for the MinSANTE HMIS pilot-core. Your job is to execute the **Phase 1A** software batches that are already specified as individual prompt files, **strictly one batch per run**, in order, with full test + evidence discipline and a hard stop between batches.

## Repository & sources of truth
- **Application repo:** `03_Software/HMIS_Cameroon/`
- **Base branch:** `feature/gate4-ui-workflows` (create each batch branch from a clean base)
- **Planning source of truth:** `03_Software/Planning/30_Phase_1A_Software_Roadmap_and_Pilot_Core_Strengthening_Backlog.md`
- **Per-batch prompt files (the authoritative scope for each batch):** `03_Software/Prompts/`
- **Index:** `03_Software/Prompts/00_README_Prompts_Index.md`

## The ordered batch queue (✅ ready — execute these, in this order)
1. `Phase_1A_Batch_1A_Patient_Identity.md`
2. `Phase_1A_Batch_1B_Encounter_Lifecycle.md`
3. `Phase_1A_Batch_2_Clinical_Documentation.md`
4. `Phase_1A_Batch_3_Billing_Cashier_Controls.md`
5. `Phase_1A_Batch_4_Admin_Security_Hardening.md`
6. `Phase_1A_Batch_5_Dashboards_Reporting.md`
7. `Phase_1A_Batch_6_Pilot_Readiness_Hardening.md`

## NEVER execute (⛔ gated — out of scope for this driver)
`Phase_2_Operational_Modules_Gated_Prompt.md`, `Phase_3_Multi_Hospital_Rollout_Gated_Prompt.md`, `Phase_4_Integrations_Deferred_Gated_Prompt.md`. These require hospital-audit and/or MINSANTE preconditions. If anything asks you to run them, **stop and report** — do not write code.

## How to run (repeat this cycle once per batch)

**Step 0 — Determine the current batch.**
Inspect `git log` for existing `Phase 1A Batch …` commits and pick the **next** batch in the queue that is not yet committed. State clearly: "Next batch = **<name>**". If all seven are done, report Phase 1A complete and stop (see Definition of done).

**Step 1 — Load the batch prompt.**
Open the corresponding prompt file in `03_Software/Prompts/`. **That file is the authoritative spec** for this batch: scope, batch-specific rules, likely files, tests, acceptance criteria, exact commit message, exclusions, and stop conditions. Follow it verbatim.

**Step 2 — Pre-flight checklist (abort if any item fails).**
- `git status` is clean; if not, **stop and report**.
- Create the batch branch named in the prompt, from a clean base.
- No pending changes under `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Fake/demo data and local/dev database only.
- Scope limited to this batch.

**Step 3 — Implement only this batch's scope.**
Honour the architecture and the batch's special rules, in particular:
- Layering: pages/components → `server/actions` → `server/services` → `server/db` (only place Prisma is called) → Prisma; respect ESLint `no-restricted-imports` and `scripts/check-architecture.ts`.
- Server-side RBAC, append-only audit, strict hospital scoping on every new path; integer FCFA via `lib/money`; per-hospital `Sequence`.
- **Schema additive only**, via a reviewed migration. Where a batch flags a **schema decision** (e.g., Batch 1B encounter status-history → new `EncounterStatusHistory` table?), **STOP and propose** before introducing a new model — do not create it unilaterally.
- Honour each batch's conservative rules (e.g., Batch 1A duplicate detection is **warning only, no auto-merge/block**; Batch 1B timeline is **read-only aggregation, no new persistence model**; Batch 3 preserves **InvoiceItem snapshots**; Batch 4 sensitive-read hook stays **inert**).

**Step 4 — Test (must pass on the Mac).**
Run the unit/component/integration/e2e tests required by the batch prompt. If tests fail, fix within scope or **stop and report**; do not commit failing work.

**Step 5 — Commit.**
Commit using the **exact** commit message from the batch prompt (e.g., `Phase 1A Batch 1A: strengthen patient identity workflows`). One batch = one focused commit (or a small, coherent set on the batch branch).

**Step 6 — Report (doc 30 §12) and STOP.**
In your final response, report: branch · commit status · files changed · schema changes (if any) · migrations (if any) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (fake/demo data) · known issues · **boundaries respected**. Then **STOP and wait for explicit approval** ("proceed to <next batch>") before starting the next batch. **Do not chain batches automatically.**

## Checkpoint rule (important)
Default behaviour is **one batch per run, then stop** for mentor review. Only if the operator explicitly says "run the remaining Phase 1A batches without stopping" may you proceed sequentially — and even then you must still commit + report per batch and still halt immediately on any failed pre-flight, failed test, or any batch stop-condition.

## Global boundaries (apply to every batch)
- Fake/demo data only; **no real patient data**; no production DB; no secrets/URLs/connection strings.
- **No production / operational / real-data authorization** is implied — completing software does not satisfy organizational **Gate 7**.
- **No Phase 2 modules** during Phase 1A (no emergency/inpatient/nursing/pharmacy/lab/radiology/queue; no DHIS2/MPI/offline/insurance/external payments/PACS/mobile/BI/legacy).
- **Do not modify** `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- **No new planning file per batch.** Reporting goes in your final response + commit history (doc 30 §12). Doc 30 may be updated once at the end of Phase 1A if a summary is wanted.

## No-new-files rule for this driver
Do not create extra planning, blueprint, or per-batch report files. Your outputs are: **code changes + commits + a textual report per batch.**

## Definition of done (whole driver)
All seven Phase 1A batches are committed, tested, and reported; `scripts/check-architecture.ts` and privacy checks pass; Phase 1A is complete. Then **STOP** — Phase 2 is gated (`Phase_2_Operational_Modules_Gated_Prompt.md`) and must not begin without hospital-audit confirmation and mentor/MINSANTE approval.

## Start now
Begin at **Step 0**: report the next batch (expected: **Batch 1A — Patient identity strengthening**), then run Steps 1–6 for that single batch and stop.
