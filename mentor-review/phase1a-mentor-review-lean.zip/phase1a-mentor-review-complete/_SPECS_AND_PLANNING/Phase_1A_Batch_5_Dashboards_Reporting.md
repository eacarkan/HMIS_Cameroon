# Claude Code Prompt — Phase 1A · Batch 5 — Dashboard / reporting strengthening

> **Status: ✅ Ready to run** (after Batch 4). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 5).

## Role & context
Continue Phase 1A on **fake/demo data**. Provide **role-specific operational visibility** from existing data — with **no BI / data warehouse**.

## Hard boundaries
- Fake/demo data only; no real data; no production DB; no secrets/URLs.
- No production/operational/real-data authorization (not Gate 7).
- **No BI/data warehouse; no external BI tool; no cross-hospital analytics** (cross-hospital is Phase 3 if approved).
- Do not modify `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Architecture layering + ESLint/`check-architecture`; server-side RBAC; append-only audit; **strict hospital scoping**.
- **No new write models** — read-only aggregations only. If a schema change seems needed, **stop and propose**.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Branch `feature/phase1a-batch-5-dashboards-reporting` from clean base.
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 5.

## Scope (tasks)
1. **Role-specific dashboards.**
2. **Daily patient activity.**
3. **Daily encounter activity.**
4. **Daily billing summary.**
5. **Cashier summary.**
6. **Basic hospital management indicators.**
7. **No BI / data warehouse.**

## Implementation rules specific to this batch
- All figures are **read-only aggregations** over existing models, **hospital-scoped**.
- Each role sees only what its capabilities permit; verify **no scoping leaks** across hospitals or roles.
- Watch aggregation **performance** on larger demo datasets.

## Files likely affected (confirm before editing)
dashboard module, reporting service/db (read-only aggregations), dashboard routes under `app/(app)/`, `features/dashboard/*`.

## Tests required
- Unit: aggregation correctness.
- Component: dashboard cards per role.
- Integration: role-scoped data; no cross-hospital leak.
- E2E: dashboard per role.

## Acceptance criteria
- Each role sees a **role-appropriate dashboard**.
- **Daily patient, encounter and billing/cashier summaries** are available.
- All figures are **read-only aggregations**, **hospital-scoped**.
- **No BI/warehouse** or cross-hospital analytics is introduced.

## Evidence required (doc 30 §12)
branch · commit status · files changed · schema changes (none expected) · migrations (none expected) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (each role dashboard; daily activity; billing/cashier summary) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 5: strengthen dashboards and reporting`

## Explicit exclusions
No data warehouse; no external BI tool; no cross-hospital analytics (Phase 3 if approved).

## Stop conditions
Stop and propose if a write model/schema change seems needed; stop if a report would require cross-hospital data or touch contract/admin folders.
