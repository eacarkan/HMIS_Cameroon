# Claude Code Prompt — Phase 1A · Batch 3 — Billing / cashier strengthening

> **Status: ✅ Ready to run** (after Batch 2). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 3).

## Role & context
Continue Phase 1A on **fake/demo data**. Add **financial-integrity controls** (corrections, reprints, shift closing) around the existing invoice/payment/receipt flow. **The InvoiceItem snapshot rule must be preserved** — past invoices never change when tariffs change.

## Hard boundaries
- Fake/demo data only; no real data; no production DB; no secrets/URLs.
- No production/operational/real-data authorization (not Gate 7).
- **No external payment gateways, no insurance/mutuelle, no external accounting integration** (Phase 4).
- Do not modify `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Architecture layering + ESLint/`check-architecture`; server-side RBAC; append-only audit; hospital scoping; integer FCFA via `lib/money`; per-hospital `Sequence` numbering.
- Schema additive only via reviewed migration; if a new model is needed (e.g., shift-closing record), **stop and propose first**.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Branch `feature/phase1a-batch-3-billing-cashier` from clean base.
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 3.

## Scope (tasks)
1. **Invoice cancellation / voiding rules** (with reason).
2. **Receipt reprint rules.**
3. **Voided / cancelled receipt marking.**
4. **Cashier shift closing.**
5. **Totals by payment mode.**
6. **Cashier report filters.**
7. **Export hardening.**

## Implementation rules specific to this batch
- Every money-affecting action (cancel/void/reprint/close) is **audited** with reason where applicable.
- **InvoiceItem snapshots remain immutable**; voiding creates a controlled state change, it does not rewrite history.
- Reprinted receipts are clearly **marked as reprint**; voided receipts marked **voided**.
- Shift closing computes **totals by payment mode** and is reproducible.

## Files likely affected (confirm before editing)
billing/tariff service (`server/services/tariff-service`), invoice/payment service & db, receipt handling, cashier report module, CSV export, `app/(app)/facturation/*`, `app/(app)/factures/[id]/*`, `app/(app)/recus/[id]/*`.

## Tests required
- Unit: void/cancel rules; shift totals; payment-mode aggregation.
- Component: cashier screens (cancel/void/reprint/shift-close).
- Integration: void → audit; shift close → totals.
- E2E: cashier day cycle (issue → pay → reprint → void → close).

## Acceptance criteria
- An invoice can be **cancelled/voided per defined rules** with reason and audit.
- A **reprinted receipt is marked as reprint**; a **voided receipt is marked voided**.
- A cashier can **close a shift** with **totals by payment mode**.
- The cashier report supports **filters**; export is hardened.
- **InvoiceItem snapshots remain unchanged** by later tariff changes.
- **Every money-affecting action is audited**; **hospital scoping** enforced.

## Evidence required (doc 30 §12)
branch · commit status · files changed · schema changes (if any; state shift-closing decision) · migrations (if any) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (cancelled invoice, voided/reprinted receipt marking, shift-closing totals, filtered report, export sample) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 3: strengthen billing and cashier controls`

## Explicit exclusions
No external payment gateways; no insurance/mutuelle; no refunds to external systems; no accounting-system integration.

## Stop conditions
Stop and propose if a new schema model is needed; stop if any change would alter historical InvoiceItem snapshots or touch contract/admin folders.
