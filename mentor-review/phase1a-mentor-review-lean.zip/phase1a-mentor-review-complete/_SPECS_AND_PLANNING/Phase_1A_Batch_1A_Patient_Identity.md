# Claude Code Prompt — Phase 1A · Batch 1A — Patient identity strengthening

> **Status: ✅ Ready to run** (recommended first coding move). Run on the Mac, against `03_Software/HMIS_Cameroon/`, after mentor approval. Planning reference: `03_Software/Planning/30_Phase_1A_Software_Roadmap_and_Pilot_Core_Strengthening_Backlog.md` §6 (Batch 1A).

## Role & context
You are implementing a small, test-proven software increment in the MinSANTE HMIS pilot-core. The app already supports (on **fake/demo data**): login, hospital selection, role-aware nav, patient search-before-create, patient registration, identity/contact/identifier/duplicate panel, encounter, consultation, observations/diagnosis, DB-driven tariffs, invoice/payment/receipt, cashier report, CSV export, dashboard, audit log, server-side RBAC, hospital scoping, user lifecycle, automated tests. This batch makes **patient lookup and duplicate awareness safer at registration**, without ever deciding identity automatically.

## Hard boundaries (do not violate)
- **Fake/demo data only**; no real patient data; no production DB; no secrets/URLs.
- **No production / operational / real-data authorization** is implied. This is not Gate 7.
- **No Phase 2 modules**, no appointment/queue module, no merge/delete of patients.
- **Do not modify** `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- **Schema additive only**, via reviewed migration — but this batch should need **no new persistence model** (new query filters and read paths over existing patient/identifier/contact models). If you believe a schema change is required, **stop and propose it first**.
- **Architecture layering:** pages/components → `server/actions` → `server/services` → `server/db` (only place Prisma is called) → Prisma. Respect ESLint `no-restricted-imports` and `scripts/check-architecture.ts`.
- **Server-side RBAC, append-only audit, hospital scoping** on every new query.

## Pre-flight checklist (abort if any fails)
1. `git status` is clean; if not, stop and report.
2. Confirm current branch base is `feature/gate4-ui-workflows` (or the agreed base); create a new branch `feature/phase1a-batch-1a-patient-identity` from a clean base.
3. Confirm no pending changes under `01_Administratif_et_Contrat/**`, `02_Package_Contractuel_Final/**`.
4. Confirm fake/demo data and local/dev database only.
5. Confirm scope is limited to Batch 1A below.

## Scope (tasks)
1. **Improve patient search filters** (name + structured filters).
2. **Search by phone / identifier.**
3. **Automatic duplicate warning at registration** — **warning only**: **no automatic merge, no automatic blocking** unless an exact-match rule is separately approved. The warning **alerts the user** and the user **continues or cancels** per defined rules.
4. The duplicate-warning event is **logged/audited**.
5. **No automatic merge** and **no destructive duplicate handling.**

## Implementation rules specific to this batch
- Keep duplicate matching **conservative** (avoid false positives); thresholds must be explicit and tested.
- The warning must **never auto-decide identity**; it surfaces likely candidates and lets the user choose.
- All new reads are **hospital-scoped** and pass through `server/db`.

## Files likely affected (confirm before editing)
`server/services/patient-identity-service`, `server/db/patient-identity.ts`, `app/(app)/patients/*`, `app/(app)/patients/nouveau/*`, `features/patients/*`, `components/*`. (Verify actual paths in the repo.)

## Tests required (must pass on the Mac)
- **Unit:** search + duplicate-match logic; warning thresholds.
- **Component:** search form (name/phone/identifier); duplicate-warning dialog.
- **Integration:** registration flow triggers warning + audit event.
- **E2E:** reception searches, then registers with and without a duplicate warning.

## Acceptance criteria
- A receptionist can **search by name, phone and identifier**.
- A **duplicate warning appears before saving** when likely-duplicate data is entered.
- The user can **continue or cancel** per defined rules; the system performs **no automatic merge or block**.
- The duplicate-warning event is **audited**.
- **Hospital scoping is enforced** for all new queries.

## Evidence required in your final response (doc 30 §12)
branch · commit status · files changed · schema changes (none expected) · migrations (none expected) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (fake data: search by each field, duplicate warning, audit entry) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 1A: strengthen patient identity workflows`

## Explicit exclusions
No automatic merge; no record deletion; no Phase 2 content; no appointment/queue module; no schema change without stop-and-propose.

## Stop conditions
Stop and ask if: a schema change seems necessary; duplicate logic would block/merge automatically; any change would touch contract/admin folders; tests cannot run.
