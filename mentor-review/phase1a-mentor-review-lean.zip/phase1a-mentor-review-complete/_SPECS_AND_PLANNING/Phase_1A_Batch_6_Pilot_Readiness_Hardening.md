# Claude Code Prompt — Phase 1A · Batch 6 — Pilot-readiness technical hardening

> **Status: ✅ Ready to run** (after Batch 5; final Phase 1A batch). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 6).

## Role & context
Complete Phase 1A on **fake/demo data**. Make the application **operable, observable, and clearly fenced for pilot** — without enabling any real-data path or production deployment.

## Hard boundaries
- Fake/demo data only; no real data; no production DB; no secrets/URLs.
- No production/operational/real-data authorization (not Gate 7).
- **No production deployment; no real backup infrastructure (supplier concern); no infrastructure provisioning.**
- Do not modify `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Architecture layering + ESLint/`check-architecture`; server-side RBAC; append-only audit; hospital scoping.
- Schema additive only via reviewed migration (e.g., a data-mode flag); if larger, **stop and propose**.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Branch `feature/phase1a-batch-6-pilot-readiness` from clean base.
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 6.

## Scope (tasks)
1. **Environment validation checks** (fail closed on misconfiguration).
2. **Fake / demo / pilot data separation** (explicit data-mode; real-data path stays disabled).
3. **Application health / status page.**
4. **Backup / restore readiness hooks** (app-level only).
5. **Error-handling consistency.**
6. **Privacy-check expansion.**
7. **Architecture-check expansion** (`scripts/check-architecture.ts`).
8. **Test-coverage expansion** (across Batches 1A–5).

## Implementation rules specific to this batch
- The **data-mode separation must not be bypassable**; the **real-data path remains disabled** and clearly indicated (visible "DEMO / PILOT — fake data" marker).
- Health checks must not create **false confidence** — report real signals (DB reachable, migrations applied, app version).
- Backup/restore are **app-level readiness hooks only**; actual backup infrastructure is a **specialized-supplier** concern (do not implement it).
- Expand `scripts/check-architecture.ts` and privacy checks to cover the new code from Batches 1A–5.

## Files likely affected (confirm before editing)
`scripts/check-architecture.ts`, privacy-check script, health/status route, environment/config validation, error boundaries, `tests/*`.

## Tests required
- Unit: env validation; data-mode guard.
- Integration: health checks; data-mode separation cannot be bypassed.
- Coverage: expand across Batches 1A–5; report coverage summary.

## Acceptance criteria
- **Environment validation** runs and **fails closed** on misconfiguration.
- **Demo/pilot data mode** is separated and **visibly indicated**, with the **real-data path disabled**.
- A **health/status page** reports app health.
- **Backup/restore readiness hooks** exist at app level.
- **Architecture and privacy checks pass**; error handling is consistent; **test coverage is expanded**.

## Evidence required (doc 30 §12)
branch · commit status · files changed · schema changes (if any; e.g., data-mode flag) · migrations (if any) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (health/status page; data-mode indicator; passing architecture/privacy checks; coverage summary) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 6: add pilot-readiness technical hardening`

## Explicit exclusions
No production deployment; no real backup infrastructure; no infrastructure provisioning.

## Stop conditions
Stop and propose if a schema change exceeds a simple additive flag; stop if any task would enable a real-data path, perform a deployment, or touch contract/admin folders.

---

## End of Phase 1A
After Batch 6 passes and is reported, Phase 1A coding is complete. If a phase-level summary is wanted, **update doc `30` once** (no per-batch planning files). Phase 2 coding does **not** begin until hospital-audit confirmation (see `Phase_2_Operational_Modules_Gated_Prompt.md`).
