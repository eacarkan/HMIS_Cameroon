# Claude Code Prompt — Phase 1A · Batch 2 — Clinical note strengthening

> **Status: ✅ Ready to run** (after Batch 1B). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 2).

## Role & context
Continue Phase 1A on **fake/demo data**. Turn the minimal consultation into a **credible, printable clinical note** — **without** introducing orders or prescriptions.

## Hard boundaries
- Fake/demo data only; no real data; no production DB; no secrets/URLs.
- No production/operational/real-data authorization (not Gate 7).
- **No prescription/order workflow** (no medication, lab, or radiology orders) — those are Phase 2 and only if separately approved.
- Do not modify `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Architecture layering + ESLint/`check-architecture`; server-side RBAC; append-only audit; hospital scoping.
- Schema additive only via reviewed migration; if a new model seems needed, **stop and propose**.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Branch `feature/phase1a-batch-2-clinical-documentation` from clean base.
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 2.

## Scope (tasks)
1. **Consultation summary.**
2. **Printable consultation note.**
3. **Improved observations / diagnosis UI.**
4. **Configurable observation/diagnosis lists where appropriate** (use existing config entities; no new module).
5. **Amendment / finalization rules** (draft → finalized; amend with trace).
6. **No prescription/order workflow** unless separately approved.

## Implementation rules specific to this batch
- Finalize/amend must be **traceable and audited** (who/when; amendments keep history).
- Configurable lists reuse existing configuration entities (e.g., settings/clinical structure); do not invent a new module.
- Print layout must handle short and long content without breaking.

## Files likely affected (confirm before editing)
consultation service/db, `server/services/clinical-structure-service`, `app/(app)/consultation/*`, `app/(app)/encounters/[id]/*`, document-template handling, `features/consultation/*`, print/templating components.

## Tests required
- Unit: finalize/amend rules; list configuration.
- Component: note editor; print view.
- Integration: consultation finalize → print; amend keeps trace.
- E2E: full consultation flow.

## Acceptance criteria
- A clinician can view a **consultation summary** and **print** a consultation note.
- Observations/diagnosis use the improved UI with **configurable lists where appropriate**.
- A consultation can be **finalized** and **amendments are traced**.
- **No prescription/order workflow** is present.
- **Hospital scoping** enforced on all new queries.

## Evidence required (doc 30 §12)
branch · commit status · files changed · schema changes (if any) · migrations (if any) · services changed · UI changed · RBAC changes · audit changes · tests run + results · screenshots (summary, printable note, finalize/amend states) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 2: strengthen clinical documentation`

## Explicit exclusions
No prescriptions; no medication orders; no lab/radiology orders; no clinical decision support.

## Stop conditions
Stop and propose if a new schema model seems needed; stop if scope drifts toward orders/prescriptions or any Phase 2 module.
