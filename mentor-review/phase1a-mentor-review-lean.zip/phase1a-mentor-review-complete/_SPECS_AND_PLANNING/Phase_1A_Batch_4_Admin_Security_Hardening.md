# Claude Code Prompt — Phase 1A · Batch 4 — Admin / security hardening

> **Status: ✅ Ready to run** (after Batch 3). Repo `03_Software/HMIS_Cameroon/`. Planning reference: `30_…` §6 (Batch 4).

## Role & context
Continue Phase 1A on **fake/demo data**. Complete **baseline account-security and admin-traceability** controls. A **sensitive-read audit hook** is wired but kept **inert** pending MINSANTE policy.

## Hard boundaries
- Fake/demo data only; no real data; no production DB; no secrets/URLs.
- No production/operational/real-data authorization (not Gate 7).
- **No SSO/identity-provider integration; no production secrets management.** The **sensitive-read policy is not activated** — only the hook is present.
- Do not modify `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- Architecture layering + ESLint/`check-architecture`; server-side RBAC; append-only audit; hospital scoping.
- Schema additive only via reviewed migration (credential/lockout/session/reset-token fields); if larger than additive, **stop and propose**.

## Pre-flight checklist (abort if any fails)
1. `git status` clean.
2. Branch `feature/phase1a-batch-4-admin-security` from clean base.
3. No pending changes under contract/admin folders.
4. Fake/demo data + local DB only.
5. Scope limited to Batch 4.

## Scope (tasks)
1. **Password change / reset.**
2. **Password policy.**
3. **Account lockout / session rules.**
4. **Role-assignment safeguards.**
5. **Admin action review.**
6. **Audit event detail page.**
7. **Sensitive-read audit hook** wired but **gated off** — **pending MINSANTE policy** (do not activate).

## Implementation rules specific to this batch
- Balance **lockout** security with usability; thresholds explicit and tested.
- **Role-assignment safeguards** prevent invalid/over-privileged grants (no silent self-escalation; least privilege).
- The **sensitive-read hook must remain inert** by default; activating it is a future MINSANTE decision.
- Reset tokens (if used) are short-lived; **no secrets committed**.

## Files likely affected (confirm before editing)
auth/config (`server/services/config-service`, `server/db/config.ts`), user lifecycle service, `lib/rbac/index.ts`, audit service, `app/(app)/administration/*`, `app/(app)/journal-audit/*`.

## Tests required
- Unit: password policy; lockout; role-assignment safeguards.
- Component: password & admin screens; audit detail view.
- Integration: reset flow; audit event detail.
- E2E: admin lifecycle (change password, lockout, role guard).

## Acceptance criteria
- A user can **change** their password and reset per the defined flow.
- **Password policy** and **account lockout / session rules** are enforced.
- **Role-assignment safeguards** prevent invalid/over-privileged assignments.
- Admin actions are **reviewable** and audit events have a **detail view**.
- The **sensitive-read hook is present but inert** pending MINSANTE policy.
- **Hospital scoping** enforced.

## Evidence required (doc 30 §12)
branch · commit status · files changed · schema changes (additive: list fields) · migrations (if any) · services changed · UI changed · **RBAC changes** · **audit changes** · tests run + results · screenshots (password change/reset, lockout, role guard, audit detail) · known issues · boundaries respected.

## Commit
`Phase 1A Batch 4: harden admin and security`

## Explicit exclusions
No SSO/identity-provider integration; no production secrets management; sensitive-read **policy** not activated.

## Stop conditions
Stop and propose if schema change exceeds additive fields; stop if activating the sensitive-read policy seems required (that is a MINSANTE decision); stop if touching contract/admin folders.
