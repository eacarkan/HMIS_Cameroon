# 03_Software/Prompts — Claude Code Prompt Set (Index)

This folder holds **ready-to-run Claude Code prompts** that implement the software planning in `03_Software/Planning/`. Each prompt is **self-contained**: it carries its own context, boundaries, pre-flight checklist, scope, tests, evidence requirements, acceptance criteria, commit message, and stop conditions.

- **Planning source of truth:** `03_Software/Planning/` (docs `30`–`33`).
- **Application repository:** `03_Software/HMIS_Cameroon/`.
- **Base branch:** `feature/gate4-ui-workflows` (create each batch branch from a clean base).

> These prompts are **instructions for Claude Code**. Creating or reading a prompt changes nothing. Only Claude Code, run on the Mac against the repository, changes code — and only when its pre-flight checklist passes and the mentor has approved the batch.

---

## Status legend

| Status | Meaning |
|---|---|
| ✅ **Ready to run** | May be executed now (after mentor approval), in order. |
| ⛔ **Gated** | **Do not execute as coding.** Blocked until a named precondition (hospital audit and/or MINSANTE decision) is satisfied. |

---

## File → prompt mapping

| Planning file | Prompt(s) | Status |
|---|---|---|
| `30_Phase_1A_…` | `Phase_1A_Batch_1A_Patient_Identity.md` | ✅ Ready (recommended **first** coding move) |
| `30_Phase_1A_…` | `Phase_1A_Batch_1B_Encounter_Lifecycle.md` | ✅ Ready (after 1A) |
| `30_Phase_1A_…` | `Phase_1A_Batch_2_Clinical_Documentation.md` | ✅ Ready (after 1B) |
| `30_Phase_1A_…` | `Phase_1A_Batch_3_Billing_Cashier_Controls.md` | ✅ Ready (after 2) |
| `30_Phase_1A_…` | `Phase_1A_Batch_4_Admin_Security_Hardening.md` | ✅ Ready (after 3) |
| `30_Phase_1A_…` | `Phase_1A_Batch_5_Dashboards_Reporting.md` | ✅ Ready (after 4) |
| `30_Phase_1A_…` | `Phase_1A_Batch_6_Pilot_Readiness_Hardening.md` | ✅ Ready (after 5) |
| `31_Phase_2_…` | `Phase_2_Operational_Modules_Gated_Prompt.md` | ⛔ Gated — **à confirmer lors de l'audit hospitalier** |
| `32_Phase_3_…` | `Phase_3_Multi_Hospital_Rollout_Gated_Prompt.md` | ⛔ Gated — **à confirmer par le MINSANTE** |
| `33_Phase_4_…` | `Phase_4_Integrations_Deferred_Gated_Prompt.md` | ⛔ Gated — deferred; per-capability MINSANTE decision required |

---

## Driver

`01_MASTER_Run_Phase_1A_with_Claude_Code.md` — paste this into Claude Code to run the seven Phase 1A batch prompts **one batch at a time**, with a mandatory stop-and-report checkpoint between batches. It detects the next batch from the commit history and **never** executes the gated Phase 2/3/4 prompts.

## Recommended execution order (Phase 1A)

1. `Phase_1A_Batch_1A_Patient_Identity.md`
2. `Phase_1A_Batch_1B_Encounter_Lifecycle.md`
3. `Phase_1A_Batch_2_Clinical_Documentation.md`
4. `Phase_1A_Batch_3_Billing_Cashier_Controls.md`
5. `Phase_1A_Batch_4_Admin_Security_Hardening.md`
6. `Phase_1A_Batch_5_Dashboards_Reporting.md`
7. `Phase_1A_Batch_6_Pilot_Readiness_Hardening.md`

Run **one batch at a time**, each on its own branch and commit. Do **not** start the next batch until the current batch's tests pass, evidence is reported, and the mentor approves.

---

## Global boundaries (apply to every prompt)

- **Fake / demo data only.** No real patient data. No production database. No production credentials, secrets, URLs, or connection strings.
- **No production authorization, no operational-use authorization, no real-data authorization.** Completing software does **not** satisfy organizational **Gate 7** (a MINSANTE/hospital decision).
- **No Phase 2 modules during Phase 1A.** No emergency/inpatient/nursing/pharmacy/lab/radiology/queue, no DHIS2/MPI/offline/insurance/external payments/PACS/mobile/BI/legacy migration.
- **Do not modify** `01_Administratif_et_Contrat/**` or `02_Package_Contractuel_Final/**`.
- **Schema changes are additive only**, via a reviewed migration. Where a prompt flags a **schema decision**, Claude Code must **stop and propose** before introducing a new model.
- **Architecture layering is mandatory:** UI/pages/components → `server/actions` → `server/services` (business logic, RBAC, audit) → `server/db` (hospital-scoped data access; the only place Prisma is called) → Prisma. Enforced by ESLint `no-restricted-imports` and `scripts/check-architecture.ts`.
- **Server-side RBAC, append-only audit, strict hospital scoping** on every new path. Money is integer FCFA via `lib/money`. UI is French (next-intl).
- **No new planning file per batch.** After each batch, Claude Code reports in its final response and records the work in the commit history (per doc `30` §12). Doc `30` may be updated once at the end of Phase 1A if a summary is needed.

---

## Evidence required after every batch (doc 30 §12)

Branch · commit status · files changed · schema changes (if any) · migrations (if any) · services changed · UI changed · RBAC changes · audit changes · tests run (and results) · screenshots (fake/demo data) · known issues · boundaries respected.
