import {
  type AuditEntryInput,
  type HospitalContext,
  createAuditEntry,
  findAuditEntries,
  findAuditEntryById,
} from "@/server/db";
import { AuthorizationError, can } from "@/server/authz";
import type { AuthenticatedActor } from "./auth-service";

/**
 * Audit service (09 §7). Audit entries are written here, from the service layer, as
 * part of a use-case — automatically, never by hand from the UI. Append-only.
 */

/** Canonical action codes (05 §8 / 07 §11). Stored as neutral codes. */
export const AUDIT_ACTIONS = {
  authLogin: "auth.login",
  hospitalSelect: "hospital.select",
  patientCreate: "patient.create",
  encounterCreate: "encounter.create",
  // Phase 1A (Batch 1B) — encounter lifecycle (status history via append-only audit; no new table).
  encounterStatusChange: "encounter.status_change",
  encounterAssign: "encounter.assign",
  consultationCreate: "consultation.create",
  consultationUpdate: "consultation.update",
  // Phase 1A (Batch 2) — clinical note finalize / amend (amendment trace via append-only audit).
  consultationFinalize: "consultation.finalize",
  consultationAmend: "consultation.amend",
  invoiceCreate: "invoice.create",
  paymentRecord: "payment.record",
  receiptPrint: "receipt.print",
  // Phase 1A (Batch 3) — billing/cashier financial-integrity controls.
  invoiceVoid: "invoice.void",
  receiptReprint: "receipt.reprint",
  cashierShiftClose: "cashier.shift_close",
  authzDenied: "authz.denied",
  // Phase 1 (Gate 3) — configuration / master data.
  departmentCreate: "department.create",
  departmentUpdate: "department.update",
  departmentDeactivate: "department.deactivate",
  serviceUnitCreate: "service_unit.create",
  serviceUnitUpdate: "service_unit.update",
  serviceUnitDeactivate: "service_unit.deactivate",
  settingUpdate: "setting.update",
  documentTemplateCreate: "document_template.create",
  documentTemplateUpdate: "document_template.update",
  documentTemplateDeactivate: "document_template.deactivate",
  // Phase 1 (Gate 3) — patient identity / contact.
  patientContactCreate: "patient_contact.create",
  patientContactUpdate: "patient_contact.update",
  patientContactDeactivate: "patient_contact.deactivate",
  patientIdentifierCreate: "patient_identifier.create",
  patientIdentifierUpdate: "patient_identifier.update",
  patientIdentifierDeactivate: "patient_identifier.deactivate",
  patientDuplicateWarning: "patient_duplicate.warning",
  patientDuplicateReview: "patient_duplicate.review",
  // Phase 1 (Gate 3) — clinical structure.
  observationCreate: "observation.create",
  observationUpdate: "observation.update",
  diagnosisCreate: "diagnosis.create",
  diagnosisUpdate: "diagnosis.update",
  // Phase 1 (Gate 3) — tariff / price list.
  priceListCreate: "price_list.create",
  priceListUpdate: "price_list.update",
  priceListDeactivate: "price_list.deactivate",
  tariffCreate: "tariff.create",
  tariffUpdate: "tariff.update",
  tariffDeactivate: "tariff.deactivate",
  invoiceItemTariffSourceUsed: "invoice_item.tariff_source_used",
  // Phase 1 (Gate 5B) — cashier reporting, user lifecycle, logout.
  authLogout: "auth.logout",
  cashierDailyReport: "cashier.daily_report.generate",
  userCreate: "user.create",
  userActivate: "user.activate",
  userDeactivate: "user.deactivate",
  roleAssign: "role.assign",
  roleRemove: "role.remove",
  // Phase 1A (Batch 4) — account security.
  authPasswordChange: "auth.password_change",
  authPasswordReset: "auth.password_reset",
  sensitiveRead: "sensitive.read",
} as const;

/**
 * Sensitive-read audit hook (Phase 1A Batch 4) — WIRED BUT INERT. Logging which users read
 * which sensitive records is a privacy decision for the MINSANTE (`à confirmer par le
 * MINSANTE`). Until that policy is set, this flag stays `false` and `recordSensitiveRead`
 * is a no-op. Activating it must be a deliberate, reviewed change — not done here.
 */
export const SENSITIVE_READ_AUDIT_ENABLED = false;

/** Inert by default — records a `sensitive.read` audit ONLY if the policy is activated. */
export async function recordSensitiveRead(entry: {
  hospitalId: string;
  actorId: string;
  entityType: string;
  entityId: string;
  summary: string;
}) {
  if (!SENSITIVE_READ_AUDIT_ENABLED) return; // pending MINSANTE policy — no-op
  await recordAudit({
    hospitalId: entry.hospitalId,
    actorId: entry.actorId,
    action: AUDIT_ACTIONS.sensitiveRead,
    entityType: entry.entityType,
    entityId: entry.entityId,
    summary: entry.summary,
  });
}

export function recordAudit(entry: AuditEntryInput) {
  return createAuditEntry(entry);
}

/**
 * Read the audit log for the active hospital (09 §7). Read-only — requires
 * `audit.read`; a denied read throws without spamming the log with its own entry.
 */
export async function listAuditEntries(
  actor: AuthenticatedActor,
  ctx: HospitalContext,
  opts: { action?: string } = {},
) {
  if (!can(actor.roles, "audit.read")) {
    throw new AuthorizationError("audit.read");
  }
  return findAuditEntries(ctx.hospitalId, { action: opts.action, limit: 100 });
}

/** Read a single audit entry (detail view). Requires `audit.read`; hospital-scoped. */
export async function getAuditEntry(
  actor: AuthenticatedActor,
  ctx: HospitalContext,
  id: string,
) {
  if (!can(actor.roles, "audit.read")) {
    throw new AuthorizationError("audit.read");
  }
  return findAuditEntryById(ctx.hospitalId, id);
}
